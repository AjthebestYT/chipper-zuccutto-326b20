
alter function public.touch_updated_at() set search_path = public;
